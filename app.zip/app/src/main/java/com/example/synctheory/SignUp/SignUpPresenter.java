package com.example.synctheory.SignUp;

public class SignUpPresenter implements SignUpContract.Presenter{

    private SignUpContract.View mView;

    public SignUpPresenter(){

    }

    @Override
    public void setView(SignUpContract.View view) {
        mView = view;
    }

    @Override
    public void start() {
        mView.setPresenter(this);
    }

    @Override
    public void stop() {

    }

    @Override
    public void signUpClicked() {
        //Get Components
        String email = mView.getEtEmail();
        String phoneNumber = mView.getEtNumber();
        String password = mView.getEtPassword();
        Boolean checkElevUser = mView.getCheckElevUser();

        //Store in database



        //Finish activity
        mView.finishSignUpActivity();
    }

    @Override
    public void backClicked() {
        mView.finishSignUpActivity();
    }
}
