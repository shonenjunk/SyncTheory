package com.example.synctheory.Note;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.example.synctheory.R;

public class NoteActivity extends AppCompatActivity {

    EditText etNote;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);
        //assigns the note to the edit text
        etNote = (EditText) findViewById(R.id.editTextNote);



        String note = etNote.getText().toString();

        Intent callingIntent = this.getIntent();
        String course = callingIntent.getStringExtra("CourseName");
        String lectureName = callingIntent.getStringExtra("LectureName");

        getSupportActionBar().setTitle(course + ": " + lectureName); // set the top title

        // Write a message to the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference(course).child(lectureName).child("note"); //note is hardcoded, will be changed to general id passed in from an intent.


        //edit text on enter key pressed listener, update the current note in firebase, unfocus keyboard, etc.
        etNote.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if(i == EditorInfo.IME_ACTION_DONE);{
                    //update the current note, close out of the keyboard
                    myRef.setValue(etNote.getText().toString());
                    InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    inputMethodManager.hideSoftInputFromWindow(etNote.getWindowToken(), 0);
                }
                return false;
            }
        });

        // Read from the database
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String value = dataSnapshot.getValue(String.class);
                etNote.setText(value);
                Log.d("TAG", "Value is: " + value);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("TAG", "Failed to read value.", error.toException());
            }
        });

    }
}