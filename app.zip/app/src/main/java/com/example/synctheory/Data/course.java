package com.example.synctheory.Data;

public class course {
    private String CourseName;

    public String getCourseName() {
        return CourseName;
    }

    public void setCourseName(String courseName) {
        this.CourseName = courseName;
    }



}
