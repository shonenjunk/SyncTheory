package com.example.synctheory.Data;

public class lecture {
    private String LectureName;

    public String getLectureName() {
        return LectureName;
    }

    public void setLectureName(String lectureName) {
        LectureName = lectureName;
    }
}
