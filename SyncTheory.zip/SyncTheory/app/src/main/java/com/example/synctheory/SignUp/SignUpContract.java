package com.example.synctheory.SignUp;

public interface SignUpContract {

        interface View{
            void setPresenter(Presenter presenter);

            void finishSignUpActivity();

            void setEtName(String name);
            void setEtEmail(String email);
            void setEtNumber(String number);
            void setEtPassword(String password);

            String getEtName();
            String getEtEmail();
            String getEtNumber();
            String getEtPassword();
        }

        interface Presenter{
            void setView(View view);
            void start();
            void stop();

            void signUpClicked();
            void backClicked();
        }
}

