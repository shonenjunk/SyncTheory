package com.example.synctheory.Login;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.synctheory.R;
import com.example.synctheory.SignUp.SignUp;


public class LoginViewFragment extends Fragment implements LoginContract.View {

    private LoginContract.Presenter mPresenter;
    Button btnGo;
    Button btnNewUser;
    EditText etEmail;
    EditText etPassword;
    ImageView ivLogo;
    TextView tvMessage;

    public LoginViewFragment() {
        // Required empty public constructor
    }

    public static LoginViewFragment newInstance() {
        LoginViewFragment fragment = new LoginViewFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public void onResume(){ super.onResume(); }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root =  inflater.inflate(R.layout.fragment_login_view, container, false);

        btnGo = root.findViewById(R.id.btnGo);
        btnGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mPresenter.goClicked();
            }
        });

        btnNewUser = root.findViewById(R.id.btnNewUser);
        btnNewUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mPresenter.newUserClicked();
            }
        });

        etEmail = root.findViewById(R.id.etEmail);

        etPassword = root.findViewById(R.id.etPassword);

        tvMessage = root.findViewById(R.id.tvMessage);

        ivLogo = root.findViewById(R.id.ivLogo);

        return root;
    }

    @Override
    public void createNewUser() {
        Intent newUserIntent = new Intent(this.getContext(), SignUp.class);
        Pair[] pairs = new Pair[4];
        pairs[0] = new Pair<View, String>(ivLogo, "logo_image");
        pairs[1] = new Pair<View, String>(tvMessage, "welcome_message");
        pairs[2] = new Pair<View, String>(etEmail, "email_transition");
        pairs[3] = new Pair<View, String>(etPassword, "password_transition");

        ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(this.getActivity(), pairs);
        startActivity(newUserIntent, options.toBundle());
    }

    @Override
    public void startCourseListActivity() {
        //Intent courseListIntent = new Intent(this.getContext(), courseListActivity.class);
        //startActivity(courseListIntent);
    }


    @Override
    public String getEtEmail() {
        if(this.etEmail.getText() == null){
            return "";
        }
        else{
            return String.valueOf(this.etEmail.getText());
        }
    }
    @Override
    public String getEtPassword() {
        if(this.etPassword.getText() == null){
            return "";
        }
        else{
            return String.valueOf(this.etPassword.getText());
        }
    }

    @Override
    public void setPresenter(LoginContract.Presenter presenter) {
        mPresenter = presenter;
    }
    @Override
    public void setEtEmail(String email) { this.etEmail.setText(email); }
    @Override
    public void setEtPassword(String password) { this.etPassword.setText(password); }
}