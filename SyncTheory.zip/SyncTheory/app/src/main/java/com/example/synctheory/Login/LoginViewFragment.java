package com.example.synctheory.Login;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.example.synctheory.R;
import com.example.synctheory.SignUp.SignUp;


public class LoginViewFragment extends Fragment implements LoginContract.View {

    private LoginContract.Presenter mPresenter;
    Button btnGo;
    Button btnNewUser;
    EditText etEmail;
    EditText etPassword;

    public LoginViewFragment() {
        // Required empty public constructor
    }

    public static LoginViewFragment newInstance() {
        LoginViewFragment fragment = new LoginViewFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public void onResume(){ super.onResume(); }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root =  inflater.inflate(R.layout.fragment_login_view, container, false);

        btnGo = root.findViewById(R.id.btnGo);
        btnGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mPresenter.goClicked();
            }
        });

        btnNewUser = root.findViewById(R.id.btnNewUser);
        btnNewUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mPresenter.newUserClicked();
            }
        });

        etEmail = root.findViewById(R.id.etEmail);

        etPassword = root.findViewById(R.id.etPassword);

        return root;
    }

    @Override
    public void createNewUser() {
        Intent newUserIntent = new Intent();
        newUserIntent.setClass(this.getContext(), SignUp.class);
        startActivity(newUserIntent);
    }


    @Override
    public String getEtEmail() {
        if(this.etEmail.getText() == null){
            return "";
        }
        else{
            return String.valueOf(this.etEmail.getText());
        }
    }
    @Override
    public String getEtPassword() {
        if(this.etPassword.getText() == null){
            return "";
        }
        else{
            return String.valueOf(this.etPassword.getText());
        }
    }

    @Override
    public void setPresenter(LoginContract.Presenter presenter) {
        mPresenter = presenter;
    }
    @Override
    public void setEtEmail(String email) { this.etEmail.setText(email); }
    @Override
    public void setEtPassword(String password) { this.etPassword.setText(password); }
}