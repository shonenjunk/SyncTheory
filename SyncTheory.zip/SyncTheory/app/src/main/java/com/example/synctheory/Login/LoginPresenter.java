package com.example.synctheory.Login;

import android.util.Log;

public class LoginPresenter implements LoginContract.Presenter{
    private LoginContract.View mView;

    public LoginPresenter(){

    }

    @Override
    public void setView(LoginContract.View view) {
        mView = view;
    }

    @Override
    public void start() {
        mView.setPresenter(this);
    }

    @Override
    public void stop() {

    }

    @Override
    public void goClicked() {
        String email = mView.getEtEmail();
        String password = mView.getEtPassword();

        /*
        //Check to see if Email and Password Exist and match
        if(Some function call to the database here to return true or false)) {
            mView.startClassActivity();
        }
        else {
            //mView.displayErrorMessage();
            Log.d("LOGIN PRESENTER", "Wrong Login Credentials");
        }
        */

    }

    @Override
    public void newUserClicked() {
        mView.createNewUser();
    }

}
